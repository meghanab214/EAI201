import pandas as pd
import os # To check file existence

# --- Configuration ---
RESULTS_FILENAME = "results.csv"  # Input file
FORMER_NAMES_FILENAME = "former_names.csv" # Mapping file
OUTPUT_FILENAME = "results_cleaned.csv" # Output file

# --- Check if input files exist ---
if not os.path.exists(RESULTS_FILENAME):
    print(f"Error: Input file '{RESULTS_FILENAME}' not found.")
    exit()
if not os.path.exists(FORMER_NAMES_FILENAME):
    print(f"Error: Input file '{FORMER_NAMES_FILENAME}' not found.")
    exit()

# Load the datasets
print(f"Loading '{RESULTS_FILENAME}' and '{FORMER_NAMES_FILENAME}'...")
try:
    results_df = pd.read_csv(RESULTS_FILENAME)
    former_names_df = pd.read_csv(FORMER_NAMES_FILENAME)
    print("Files loaded successfully.")
except Exception as e:
    print(f"An unexpected error occurred while loading files: {e}")
    exit()

# --- Data Cleaning Steps ---
print("\nStarting data cleaning...")

# 1. Identify Team Name Columns
home_team_col = 'home_team'
away_team_col = 'away_team'

if home_team_col not in results_df.columns or away_team_col not in results_df.columns:
    print(f"Error: Expected columns '{home_team_col}' and '{away_team_col}' not found in {RESULTS_FILENAME}.")
    print(f"Actual columns: {results_df.columns.tolist()}")
    exit()

# 2. Handle Missing Values
initial_rows = len(results_df)
results_df.dropna(subset=[home_team_col, away_team_col], inplace=True)
dropped_rows = initial_rows - len(results_df)
if dropped_rows > 0:
    print(f"- Dropped {dropped_rows} rows due to missing team names.")

# 3. Create the Name Mapping Dictionary
name_mapping = dict(zip(former_names_df['former'], former_names_df['current']))
print("- Created name mapping dictionary.")

# 4. Apply the Mapping to Home and Away Team Names
print(f"- Applying name standardization to '{RESULTS_FILENAME}'...")
results_df[home_team_col] = results_df[home_team_col].replace(name_mapping)
results_df[away_team_col] = results_df[away_team_col].replace(name_mapping)
print("- Name standardization applied.")

# --- Verification ---
print("\nTeam name cleaning complete.")

# Optional: Check a specific name replacement
if 'German DR' in name_mapping: # East Germany
    remaining_gdr_count = (results_df[home_team_col] == 'German DR').sum() + \
                          (results_df[away_team_col] == 'German DR').sum()
    if remaining_gdr_count == 0:
        print("- Verified: 'German DR' instances (if any) updated to 'Germany'.")

# Display the first few rows with potentially updated names
print("\nPreview of cleaned DataFrame:")
print(results_df.head())

# --- Save Cleaned Data ---
print(f"\nSaving cleaned data to '{OUTPUT_FILENAME}'...")
try:
    results_df.to_csv(OUTPUT_FILENAME, index=False)
    print(f"Cleaned data saved successfully to '{OUTPUT_FILENAME}'")
except Exception as e:
    print(f"\nError saving cleaned data to '{OUTPUT_FILENAME}': {e}")
