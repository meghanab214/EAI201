import pandas as pd
import os # Import os library

# --- Add these lines for debugging ---
current_directory = os.getcwd()
print(f"DEBUG: Current Working Directory: {current_directory}")
print("\nDEBUG: Files/Folders in this directory:")
try:
    print(os.listdir(current_directory))
except Exception as e:
    print(f"DEBUG: Could not list directory contents: {e}")
print("-" * 30) # Separator
# --- End of added lines ---


# --- Configuration ---
RESULTS_CLEANED_FILE = "results_cleaned.csv"
PLAYERS_FILE = "WorldCupPlayers.csv"
RANKINGS_FILE = "fifa_rankings_extracted.csv" # Using the user's actual filename

# --- Load DataFrames ---
print("Loading datasets into pandas DataFrames...")

try:
    # Load historical match results
    results_df = pd.read_csv(RESULTS_CLEANED_FILE)
    print(f"\nSuccessfully loaded '{RESULTS_CLEANED_FILE}'.")
    print("Results DataFrame Info:")
    results_df.info()
    # print("\nResults DataFrame Head:") # Commenting out head() for brevity during debug
    # print(results_df.head())

    # Load World Cup player data
    players_df = pd.read_csv(PLAYERS_FILE)
    print(f"\nSuccessfully loaded '{PLAYERS_FILE}'.")
    print("Players DataFrame Info:")
    players_df.info()
    # print("\nPlayers DataFrame Head:") # Commenting out head() for brevity
    # print(players_df.head())

    # Load scraped FIFA rankings using the corrected filename
    print(f"\nAttempting to load: {RANKINGS_FILE}") # Added print before loading
    rankings_df = pd.read_csv(RANKINGS_FILE)
    print(f"\nSuccessfully loaded '{RANKINGS_FILE}'.")
    print("Rankings DataFrame Info:")
    rankings_df.info()
    # print("\nRankings DataFrame Head:") # Commenting out head() for brevity
    # print(rankings_df.head())

    print("\nAll necessary DataFrames loaded successfully")

except FileNotFoundError as e:
    print(f"\nError: {e}")
    # Be more specific about the file in the error message
    if str(e).endswith(f"'{RANKINGS_FILE}'"):
         print(f"Could not find the rankings file named '{RANKINGS_FILE}'.")
    elif str(e).endswith(f"'{RESULTS_CLEANED_FILE}'"):
        print(f"Could not find the results file named '{RESULTS_CLEANED_FILE}'.")
    elif str(e).endswith(f"'{PLAYERS_FILE}'"):
         print(f"Could not find the players file named '{PLAYERS_FILE}'.")
    print("Please make sure all required CSV files are in the same directory as the script and the filenames match exactly.")
    # Add hint about working directory
    print(f"Also ensure you are running the script from this directory: {current_directory}")
except Exception as e:
    print(f"\nAn unexpected error occurred: {e}")

