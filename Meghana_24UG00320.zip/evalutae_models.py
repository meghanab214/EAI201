import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.metrics import (
    classification_report, confusion_matrix, ConfusionMatrixDisplay,
    accuracy_score, roc_curve, auc
)
import joblib # To load models and scaler
import matplotlib.pyplot as plt # For plotting
from itertools import cycle # For plotting ROC curves
import os

# --- Configuration ---
INPUT_FILE = "match_data_with_complete_features.csv"
ROLLING_WINDOW_SIZE = 50 # Must match the window used in previous steps
MODEL_SAVE_DIR = "trained_models"
VISUALIZATION_SAVE_DIR = "visualizations"
os.makedirs(VISUALIZATION_SAVE_DIR, exist_ok=True) # Ensure viz directory exists
N_CLASSES = 3 # Home Win, Draw, Away Win
TARGET_NAMES = ['Home Win (0)', 'Draw (1)', 'Away Win (2)']

# --- Check if necessary files/folders exist ---
required_files = [
    INPUT_FILE,
    os.path.join(MODEL_SAVE_DIR, 'scaler.pkl'),
    os.path.join(MODEL_SAVE_DIR, 'logistic_regression_model.pkl'),
    os.path.join(MODEL_SAVE_DIR, 'random_forest_model.pkl')
]
missing_files = [f for f in required_files if not os.path.exists(f)]
if missing_files:
    print("Error: The following required files/folders are missing:")
    for f in missing_files:
        print(f"- {f}")
    print("Please ensure feature_engineering.py and train_models.py ran successfully.")
    exit()

# --- Load Models and Scaler ---
print("Loading scaler and trained models...")
try:
    scaler = joblib.load(os.path.join(MODEL_SAVE_DIR, 'scaler.pkl'))
    log_reg_model = joblib.load(os.path.join(MODEL_SAVE_DIR, 'logistic_regression_model.pkl'))
    rf_model = joblib.load(os.path.join(MODEL_SAVE_DIR, 'random_forest_model.pkl'))
    print("Scaler and models loaded successfully.")
except Exception as e:
    print(f"An error occurred loading .pkl files: {e}")
    exit()

# --- Load and Prepare Data ---
print(f"\nLoading and preparing data from '{INPUT_FILE}' to get test set...")
try:
    df = pd.read_csv(INPUT_FILE)
    df['date'] = pd.to_datetime(df['date'])
    feature_cols = [
        f'home_avg_pts_L{ROLLING_WINDOW_SIZE}', f'home_avg_gd_L{ROLLING_WINDOW_SIZE}',
        f'away_avg_pts_L{ROLLING_WINDOW_SIZE}', f'away_avg_gd_L{ROLLING_WINDOW_SIZE}',
        'home_rank', 'away_rank', 'rank_diff', 'neutral'
    ]
    if 'neutral' not in df.columns: df['neutral'] = False
    df['neutral'] = df['neutral'].astype(int)
    df['result'] = np.select(
        [df['home_score'] > df['away_score'], df['home_score'] == df['away_score']],
        [0, 1], default=2
    )
    target_col = 'result'
    median_home_rank = df['home_rank'].median()
    median_rank_fill = 100
    if pd.notna(median_home_rank): median_rank_fill = int(median_home_rank)
    df.loc[:, 'home_rank'] = df['home_rank'].fillna(median_rank_fill)
    df.loc[:, 'away_rank'] = df['away_rank'].fillna(median_rank_fill)
    df['rank_diff'] = df['home_rank'] - df['away_rank']
    df.dropna(subset=feature_cols + [target_col], inplace=True)
    X = df[feature_cols]
    y = df[target_col]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    X_test_scaled = scaler.transform(X_test)
    print("Test data prepared and scaled successfully.")
except Exception as e:
    print(f"An error occurred during data loading/preparation: {e}")
    exit()

# Binarize the output for OvR ROC curves
y_test_bin = label_binarize(y_test, classes=[0, 1, 2])

# --- Evaluate Logistic Regression Model ---
print("\n--- Evaluating Logistic Regression ---")
try:
    y_pred_lr = log_reg_model.predict(X_test_scaled)
    y_proba_lr = log_reg_model.predict_proba(X_test_scaled) # Get probabilities

    accuracy_lr = accuracy_score(y_test, y_pred_lr)
    print(f"Accuracy: {accuracy_lr:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_lr, target_names=TARGET_NAMES))

    # --- Confusion Matrix (LR) ---
    cm_lr = confusion_matrix(y_test, y_pred_lr, labels=log_reg_model.classes_)
    disp_lr = ConfusionMatrixDisplay(confusion_matrix=cm_lr, display_labels=TARGET_NAMES)
    fig_cm_lr, ax_cm_lr = plt.subplots(figsize=(8, 6))
    disp_lr.plot(cmap=plt.cm.Blues, ax=ax_cm_lr)
    ax_cm_lr.set_title('Logistic Regression Confusion Matrix')
    cm_lr_filename = os.path.join(VISUALIZATION_SAVE_DIR, 'confusion_matrix_lr.png')
    plt.savefig(cm_lr_filename)
    print(f"\nConfusion Matrix plot saved to '{cm_lr_filename}'")
    plt.close(fig_cm_lr)

    # --- ROC Curve (LR) ---
    print("\nCalculating ROC Curves (One-vs-Rest) for Logistic Regression...")
    fpr_lr = dict()
    tpr_lr = dict()
    roc_auc_lr = dict()

    # Calculate ROC for each class
    for i in range(N_CLASSES):
        fpr_lr[i], tpr_lr[i], _ = roc_curve(y_test_bin[:, i], y_proba_lr[:, i])
        roc_auc_lr[i] = auc(fpr_lr[i], tpr_lr[i])

    # Calculate micro-average ROC
    fpr_lr["micro"], tpr_lr["micro"], _ = roc_curve(y_test_bin.ravel(), y_proba_lr.ravel())
    roc_auc_lr["micro"] = auc(fpr_lr["micro"], tpr_lr["micro"])

    # Calculate macro-average ROC
    all_fpr_lr = np.unique(np.concatenate([fpr_lr[i] for i in range(N_CLASSES)]))
    mean_tpr_lr = np.zeros_like(all_fpr_lr)
    for i in range(N_CLASSES):
        mean_tpr_lr += np.interp(all_fpr_lr, fpr_lr[i], tpr_lr[i])
    mean_tpr_lr /= N_CLASSES
    fpr_lr["macro"] = all_fpr_lr
    tpr_lr["macro"] = mean_tpr_lr
    roc_auc_lr["macro"] = auc(fpr_lr["macro"], tpr_lr["macro"])

    # Plot all ROC curves
    fig_roc_lr, ax_roc_lr = plt.subplots(figsize=(8, 6))
    ax_roc_lr.plot(fpr_lr["micro"], tpr_lr["micro"],
             label=f'Micro-average ROC curve (area = {roc_auc_lr["micro"]:.2f})',
             color='deeppink', linestyle=':', linewidth=4)
    ax_roc_lr.plot(fpr_lr["macro"], tpr_lr["macro"],
             label=f'Macro-average ROC curve (area = {roc_auc_lr["macro"]:.2f})',
             color='navy', linestyle=':', linewidth=4)
    colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])
    for i, color in zip(range(N_CLASSES), colors):
        ax_roc_lr.plot(fpr_lr[i], tpr_lr[i], color=color, lw=2,
                 label=f'ROC curve of {TARGET_NAMES[i]} (area = {roc_auc_lr[i]:.2f})')

    ax_roc_lr.plot([0, 1], [0, 1], 'k--', lw=2)
    ax_roc_lr.set_xlim([0.0, 1.0])
    ax_roc_lr.set_ylim([0.0, 1.05])
    ax_roc_lr.set_xlabel('False Positive Rate')
    ax_roc_lr.set_ylabel('True Positive Rate')
    ax_roc_lr.set_title('Logistic Regression ROC (One-vs-Rest)')
    ax_roc_lr.legend(loc="lower right")

    # Save the ROC plot
    roc_lr_filename = os.path.join(VISUALIZATION_SAVE_DIR, 'roc_curve_lr.png')
    plt.savefig(roc_lr_filename)
    print(f"ROC curve plot saved to '{roc_lr_filename}'")
    plt.close(fig_roc_lr)

except Exception as e:
    print(f"An error occurred during Logistic Regression evaluation: {e}")

# --- Evaluate Random Forest Model ---
print("\n--- Evaluating Random Forest ---")
try:
    y_pred_rf = rf_model.predict(X_test_scaled)
    y_proba_rf = rf_model.predict_proba(X_test_scaled) # Get probabilities

    accuracy_rf = accuracy_score(y_test, y_pred_rf)
    print(f"Accuracy: {accuracy_rf:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_rf, target_names=TARGET_NAMES))

    # --- Confusion Matrix (RF) ---
    cm_rf = confusion_matrix(y_test, y_pred_rf, labels=rf_model.classes_)
    disp_rf = ConfusionMatrixDisplay(confusion_matrix=cm_rf, display_labels=TARGET_NAMES)
    fig_cm_rf, ax_cm_rf = plt.subplots(figsize=(8, 6))
    disp_rf.plot(cmap=plt.cm.Blues, ax=ax_cm_rf)
    ax_cm_rf.set_title('Random Forest Confusion Matrix')
    cm_rf_filename = os.path.join(VISUALIZATION_SAVE_DIR, 'confusion_matrix_rf.png')
    plt.savefig(cm_rf_filename)
    print(f"\nConfusion Matrix plot saved to '{cm_rf_filename}'")
    plt.close(fig_cm_rf)

    # --- ROC Curve (RF) ---
    print("\nCalculating ROC Curves (One-vs-Rest) for Random Forest...")
    fpr_rf = dict()
    tpr_rf = dict()
    roc_auc_rf = dict()

    # Calculate ROC for each class
    for i in range(N_CLASSES):
        fpr_rf[i], tpr_rf[i], _ = roc_curve(y_test_bin[:, i], y_proba_rf[:, i])
        roc_auc_rf[i] = auc(fpr_rf[i], tpr_rf[i])

    # Calculate micro-average ROC
    fpr_rf["micro"], tpr_rf["micro"], _ = roc_curve(y_test_bin.ravel(), y_proba_rf.ravel())
    roc_auc_rf["micro"] = auc(fpr_rf["micro"], tpr_rf["micro"])

    # Calculate macro-average ROC
    all_fpr_rf = np.unique(np.concatenate([fpr_rf[i] for i in range(N_CLASSES)]))
    mean_tpr_rf = np.zeros_like(all_fpr_rf)
    for i in range(N_CLASSES):
        mean_tpr_rf += np.interp(all_fpr_rf, fpr_rf[i], tpr_rf[i])
    mean_tpr_rf /= N_CLASSES
    fpr_rf["macro"] = all_fpr_rf
    tpr_rf["macro"] = mean_tpr_rf
    roc_auc_rf["macro"] = auc(fpr_rf["macro"], tpr_rf["macro"])

    # Plot all ROC curves
    fig_roc_rf, ax_roc_rf = plt.subplots(figsize=(8, 6))
    ax_roc_rf.plot(fpr_rf["micro"], tpr_rf["micro"],
             label=f'Micro-average ROC curve (area = {roc_auc_rf["micro"]:.2f})',
             color='deeppink', linestyle=':', linewidth=4)
    ax_roc_rf.plot(fpr_rf["macro"], tpr_rf["macro"],
             label=f'Macro-average ROC curve (area = {roc_auc_rf["macro"]:.2f})',
             color='navy', linestyle=':', linewidth=4)
    colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])
    for i, color in zip(range(N_CLASSES), colors):
        ax_roc_rf.plot(fpr_rf[i], tpr_rf[i], color=color, lw=2,
                 label=f'ROC curve of {TARGET_NAMES[i]} (area = {roc_auc_rf[i]:.2f})')

    ax_roc_rf.plot([0, 1], [0, 1], 'k--', lw=2)
    ax_roc_rf.set_xlim([0.0, 1.0])
    ax_roc_rf.set_ylim([0.0, 1.05])
    ax_roc_rf.set_xlabel('False Positive Rate')
    ax_roc_rf.set_ylabel('True Positive Rate')
    ax_roc_rf.set_title('Random Forest ROC (One-vs-Rest)')
    ax_roc_rf.legend(loc="lower right")

    # Save the ROC plot
    roc_rf_filename = os.path.join(VISUALIZATION_SAVE_DIR, 'roc_curve_rf.png')
    plt.savefig(roc_rf_filename)
    print(f"ROC curve plot saved to '{roc_rf_filename}'")
    plt.close(fig_roc_rf)

except Exception as e:
    print(f"An error occurred during Random Forest evaluation: {e}")

print("\n--- Model evaluation script finished. ---")