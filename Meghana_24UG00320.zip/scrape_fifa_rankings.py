import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
import os

# --- Configuration ---
URL = "https://en.wikipedia.org/wiki/FIFA_Men%27s_World_Ranking"
OUTPUT_FILENAME = "fifa_rankings_extracted.csv" # Overwrite the bad file

# --- Main Scraping Logic ---
print(f"Attempting to scrape data from: {URL}")

try:
    headers = {'User-Agent': 'Mozilla/5.0'} 
    response = requests.get(URL, headers=headers, timeout=10)
    response.raise_for_status()
    print("Successfully fetched page content.")

    soup = BeautifulSoup(response.content, 'html.parser')
    print("Successfully parsed HTML.")

    all_tables = soup.find_all('table', {'class': 'wikitable'})
    print(f"Found {len(all_tables)} 'wikitable' tables.")

    correct_table = None
    
    # Loop through tables to find the correct "Top 20" table
    for table in all_tables:
        headers = [th.get_text(strip=True).lower() for th in table.find_all('th')]
        
        # Look for the table that has the headers we need
        if 'rank' in headers and 'team' in headers and 'points' in headers:
            print(f"Found the correct 'Top 20' table with headers: {headers}")
            correct_table = table
            break # Stop after finding the first match

    if correct_table is None:
        print("Error: Could not find the correct table with 'Rank', 'Team', and 'Points' headers.")
        exit()

    all_rankings = []
    
    # Find the correct column indices
    # We strip special chars like 'Δ' from 'Change (Δ)'
    headers_clean = [re.sub(r'[^a-zA-Z]', '', h) for h in headers]
    
    try:
        rank_index = headers_clean.index("rank")
        team_index = headers_clean.index("team")
        points_index = headers_clean.index("points")
        print(f"Column indices: Rank={rank_index}, Team={team_index}, Points={points_index}")
    except ValueError as e:
        print(f"Error: Could not find expected column headers in the identified table. Headers found: {headers_clean}")
        exit()
        
    # Get date context
    date_context = "Current" # Default
    # Try to find a date in a preceding header or caption
    caption = correct_table.find('caption')
    if caption:
        date_context = caption.get_text(strip=True)
    else:
        # Check headers above the table
        prev_header = correct_table.find_previous(['h2', 'h3', 'h4'])
        if prev_header:
            date_context = prev_header.get_text(strip=True).replace('[edit]', '')
    
    print(f"Using Date Context: {date_context}")

    rows = correct_table.find_all('tr')
    
    for row in rows[1:]: # Skip header row
        cells = row.find_all(['td', 'th'])
        
        if len(cells) > max(rank_index, team_index, points_index):
            try:
                rank = cells[rank_index].get_text(strip=True)
                
                # Get team name from the link title, it's cleaner
                team_cell = cells[team_index]
                team_link = team_cell.find('a')
                if team_link and team_link.get('title'):
                    team = team_link.get('title').strip()
                else:
                    team = team_cell.get_text(strip=True) # Fallback
                    
                points = cells[points_index].get_text(strip=True)

                # Clean data
                rank = re.sub(r'[^0-9]', '', rank) # Remove non-numeric
                points = re.sub(r'[^0-9\.]', '', points) # Remove non-numeric/non-decimal
                team = re.sub(r'\s\(.*\)', '', team) # Remove things like (Seleção)

                if rank and team and points:
                    all_rankings.append({
                        'Date_Context': date_context,
                        'Rank': rank,
                        'Team': team,
                        'Points': points
                    })
            except Exception as e:
                print(f"Skipping row {row}. Error: {e}")
                
    if not all_rankings:
        print("Error: No ranking data could be extracted. Check table structure.")
        exit()

    rankings_df = pd.DataFrame(all_rankings)
    print(f"\nSuccessfully extracted {len(rankings_df)} ranking entries.")

    # Save the DataFrame to a CSV file
    rankings_df.to_csv(OUTPUT_FILENAME, index=False)
    print(f"\nScraped data saved successfully to '{OUTPUT_FILENAME}'")

    print("\nPreview of scraped data:")
    print(rankings_df.head())

except requests.exceptions.RequestException as e:
    print(f"Error during requests to {URL}: {e}")
except Exception as e:
    print(f"An error occurred: {e}")

