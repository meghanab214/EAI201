import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# --- 1. Configuration ---
DATA_FILE = "match_data_with_complete_features.csv"
MODEL_SAVE_DIR = "models"
ROLLING_WINDOW_SIZE = 50 # Must match the window size from feature_engineering.py

# Create model directory if it doesn't exist
os.makedirs(MODEL_SAVE_DIR, exist_ok=True)

# --- 2. Define Target and Features ---

def get_target(score1, score2):
    """Defines the 3-class target variable."""
    if score1 > score2:
        return 0  # Home Win
    elif score1 == score2:
        return 1  # Draw
    else:
        return 2  # Away Win

# 🔴 CRITICAL: This list MUST match the columns in your CSV file.
feature_cols = [
    # Match History Features
    f'home_avg_pts_L{ROLLING_WINDOW_SIZE}',
    f'home_avg_gd_L{ROLLING_WINDOW_SIZE}',
    f'away_avg_pts_L{ROLLING_WINDOW_SIZE}',
    f'away_avg_gd_L{ROLLING_WINDOW_SIZE}',
    
    # FIFA Ranking Features
    'home_rank',
    'away_rank',
    'rank_diff',
    'neutral',
    
    # --- FIX ---
    # Player features removed because they are not in your CSV.
    # 'home_avg_age',
    # 'away_avg_age',
    # 'home_total_exp',
    # 'away_total_exp'
]

# --- 3. Load and Prepare Data ---
print(f"Loading data from {DATA_FILE}...")
if not os.path.exists(DATA_FILE):
    print(f"Error: Data file not found at {DATA_FILE}")
    print("Please run the feature_engineering.py script first.")
    exit()

try:
    df = pd.read_csv(DATA_FILE)
except Exception as e:
    print(f"Error loading CSV: {e}")
    exit()

# Verify all required feature columns exist
missing_cols = [col for col in feature_cols if col not in df.columns]
if missing_cols:
    print(f"Error: The following required feature columns are missing from {DATA_FILE}:")
    print(missing_cols)
    print("Please ensure your feature_engineering.py script ran correctly and generated these columns.")
    exit()

print("Data loaded successfully.")

# Convert 'neutral' to integer (True=1, False=0)
df['neutral'] = df['neutral'].astype(int)

# 
# ======================================================
# === THIS IS THE LINE THAT WAS FIXED ===
# ======================================================
# Create Target Variable 'result'
df['result'] = df.apply(lambda row: get_target(row['home_score'], row['away_score']), axis=1) # Was 'home_score'

# Handle potential NaNs in features (e.g., from player data merges)
# Using median imputation as a robust strategy
imputer = SimpleImputer(strategy='median')
df[feature_cols] = imputer.fit_transform(df[feature_cols])

# Define X and y
X = df[feature_cols]
y = df['result']

print(f"Features (X) shape: {X.shape}")
print(f"Target (y) shape: {y.shape}")
print(f"Target classes found: {np.unique(y)}") # Added to confirm you have 3 classes

# --- 4. Train-Test Split ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2, 
    random_state=42, 
    stratify=y  # Important for classification with imbalanced classes
)
print("Data split into 80% train and 20% test sets.")

# --- 5. Feature Scaling ---
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("Features scaled using StandardScaler.")

# Save the scaler and test data for the evaluation script
joblib.dump(scaler, os.path.join(MODEL_SAVE_DIR, 'scaler.pkl'))
joblib.dump(X_test_scaled, os.path.join(MODEL_SAVE_DIR, 'X_test_scaled.pkl'))
joblib.dump(y_test, os.path.join(MODEL_SAVE_DIR, 'y_test.pkl'))
print("Scaler and test data saved.")

# --- 6. Model Training with Hyperparameter Tuning ---

### Logistic Regression Tuning (Task 2)
print("\n--- Tuning Logistic Regression ---")
# Define parameter grid
lr_params = {
    'C': [0.01, 0.1, 1, 10],  # Regularization strength
    'solver': ['liblinear', 'saga'] # Solvers good for this problem size
}
# Setup GridSearchCV
lr_grid = GridSearchCV(
    LogisticRegression(multi_class='ovr', random_state=42, max_iter=1000),
    param_grid=lr_params,
    cv=5, # 5-fold cross-validation
    scoring='accuracy',
    n_jobs=-1, # Use all available CPU cores
    verbose=1
)
lr_grid.fit(X_train_scaled, y_train)
best_lr = lr_grid.best_estimator_

print(f"Best Logistic Regression Params: {lr_grid.best_params_}")
print(f"Best LR Cross-val Accuracy: {lr_grid.best_score_:.4f}")

# Save the *best* tuned model
joblib.dump(best_lr, os.path.join(MODEL_SAVE_DIR, 'logistic_regression_tuned.pkl'))
print("Tuned Logistic Regression model saved.")


### Random Forest Tuning (Task 2)
print("\n--- Tuning Random Forest ---")
# Define parameter grid (smaller grid for speed, expand as needed)
rf_params = {
    'n_estimators': [100, 200],      # Number of trees
    'max_depth': [10, 20, None],     # Max depth of trees
    'min_samples_split': [2, 5]      # Min samples to split a node
}
# Setup GridSearchCV
rf_grid = GridSearchCV(
    RandomForestClassifier(random_state=42),
    param_grid=rf_params,
    cv=5, # 5-fold cross-validation
    scoring='accuracy',
    n_jobs=-1, # Use all available CPU cores
    verbose=1
)
rf_grid.fit(X_train_scaled, y_train)
best_rf = rf_grid.best_estimator_

print(f"Best Random Forest Params: {rf_grid.best_params_}")
print(f"Best RF Cross-val Accuracy: {rf_grid.best_score_:.4f}")

# Save the *best* tuned model
joblib.dump(best_rf, os.path.join(MODEL_SAVE_DIR, 'random_forest_tuned.pkl'))
print("Tuned Random Forest model saved.")

print("\n--- Model Training and Tuning Complete ---")