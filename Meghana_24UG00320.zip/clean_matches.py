import pandas as pd

# --- Configuration ---
MATCHES_FILENAME = "WorldCupMatches.csv" # Input file
FORMER_NAMES_FILENAME = "former_names.csv" # Mapping file
OUTPUT_FILENAME = "WorldCupMatches_cleaned.csv" # Output file

# Load the datasets
try:
    matches_df = pd.read_csv(MATCHES_FILENAME)
    former_names_df = pd.read_csv(FORMER_NAMES_FILENAME)
except FileNotFoundError as e:
    print(f"Error loading files: {e}")
    print(f"Make sure '{MATCHES_FILENAME}' and '{FORMER_NAMES_FILENAME}' are in the correct directory.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred while loading files: {e}")
    exit()

# --- Data Cleaning Steps ---

# 1. Identify Team Name Columns
home_team_col = 'Home Team Name'
away_team_col = 'Away Team Name'

if home_team_col not in matches_df.columns or away_team_col not in matches_df.columns:
    print(f"Error: Expected columns '{home_team_col}' and '{away_team_col}' not found in {MATCHES_FILENAME}.")
    print(f"Actual columns: {matches_df.columns.tolist()}")
    exit()

# 2. Handle Missing Values (Important!)
#    Drop rows where team names might be missing.
initial_rows = len(matches_df)
matches_df.dropna(subset=[home_team_col, away_team_col], inplace=True)
dropped_rows = initial_rows - len(matches_df)
if dropped_rows > 0:
    print(f"Dropped {dropped_rows} rows due to missing team names.")

# 3. Create the Name Mapping Dictionary
#    This dictionary will have old names as keys and current names as values.
name_mapping = dict(zip(former_names_df['former'], former_names_df['current']))

# 4. Apply the Mapping to Home and Away Team Names
#    Use .replace() to substitute names based on the dictionary.
print(f"Applying name standardization to '{MATCHES_FILENAME}'...")
matches_df[home_team_col] = matches_df[home_team_col].replace(name_mapping)
matches_df[away_team_col] = matches_df[away_team_col].replace(name_mapping)

# --- Verification ---
print("\nTeam name cleaning complete.")

# Optional: Check if any specific old names were replaced (Example: 'Germany FR')
if 'Germany FR' in name_mapping:
    # Check if 'Germany FR' still exists after replacement
    remaining_gfr_count = (matches_df[home_team_col] == 'Germany FR').sum() + \
                          (matches_df[away_team_col] == 'Germany FR').sum()
    if remaining_gfr_count == 0:
        print("Verified: 'Germany FR' instances (if any existed) have been updated to 'Germany'.")
    else:
        print(f"Warning: Found {remaining_gfr_count} instances of 'Germany FR' remaining after cleaning.")

# Display the first few rows with potentially updated names
print("\nPreview of cleaned DataFrame:")
print(matches_df.head())

# --- Save Cleaned Data ---
try:
    # These lines are now uncommented:
    matches_df.to_csv(OUTPUT_FILENAME, index=False)
    print(f"\nCleaned data saved successfully to '{OUTPUT_FILENAME}'")
except Exception as e:
    print(f"\nError saving cleaned data to '{OUTPUT_FILENAME}': {e}")