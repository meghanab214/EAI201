import pandas as pd
import numpy as np
from tqdm import tqdm
from datetime import timedelta
import os

# --- Configuration ---
RESULTS_CLEANED_FILE = "results_cleaned.csv"
RANKINGS_FILE = "fifa_rankings_extracted.csv"
PLAYERS_FILE = "WorldCupPlayers.csv"
# *** USER MUST CREATE THIS FILE ***
# This file must contain: Player Name, Birth Date (as YYYY-MM-DD or similar)
BIRTH_DATES_FILE = "player_birth_dates_EXTERNAL.csv" 

OUTPUT_FILE = "match_data_with_complete_features.csv" # New output filename
ROLLING_WINDOW_SIZE = 50 

# --- Helper Functions for Player Features (MUST BE COMPLETED BY USER) ---

def load_and_calculate_player_features(matches_df):
    """
    Loads player data, merges with birth dates, calculates age/experience,
    and aggregates to the match level.
    """
    print("\n--- Calculating Player Features (Age and Experience) ---")

    # --- 1. Load Player and External Birth Date Data ---
    if not os.path.exists(PLAYERS_FILE):
        print(f"Error: {PLAYERS_FILE} not found. Skipping player features.")
        return matches_df
    
    if not os.path.exists(BIRTH_DATES_FILE):
        print(f"Error: {BIRTH_DATES_FILE} not found. Age calculation requires birth dates. Skipping player features.")
        return matches_df
        
    try:
        players_df = pd.read_csv(PLAYERS_FILE)
        birth_dates_df = pd.read_csv(BIRTH_DATES_FILE)
        birth_dates_df['Birth_Date'] = pd.to_datetime(birth_dates_df['Birth_Date'], errors='coerce')
        birth_dates_df.dropna(subset=['Birth_Date'], inplace=True)
        
        # Ensure common column names for merging (Adjust this based on your real birth dates file)
        # Assuming birth_dates_df has 'Player Name' and 'Birth_Date'
        players_df = pd.merge(players_df, birth_dates_df[['Player Name', 'Birth_Date']], on='Player Name', how='left')
        players_df.dropna(subset=['Birth_Date'], inplace=True)
        print("Player data and birth dates merged.")
    except Exception as e:
        print(f"Error loading/merging player data: {e}. Skipping player features.")
        return matches_df

    # --- 2. Calculate Age at Match Time ---
    # Merge matches_df with players_df to get the match date for age calculation
    match_dates = matches_df[['MatchID', 'date']].rename(columns={'date': 'Match_Date'})
    players_df = pd.merge(players_df, match_dates, on='MatchID', how='left')
    players_df['Match_Date'] = pd.to_datetime(players_df['Match_Date'])
    
    # Calculate age in years
    players_df['Age_Days'] = (players_df['Match_Date'] - players_df['Birth_Date']).dt.days
    players_df['Age_Years'] = players_df['Age_Days'] / 365.25
    players_df.dropna(subset=['Age_Years'], inplace=True)
    print("Age at match time calculated.")

    # --- 3. Calculate Player Experience (Total World Cup appearances) ---
    # This simple experience metric counts the number of times a player appears in the dataset
    # before the current match (using MatchID as a proxy for time if matches_df is sorted)
    
    # Sort players by match to enable cumulative counting
    players_df.sort_values(by=['Match_Date', 'MatchID'], inplace=True)
    
    # Calculate cumulative World Cup matches played per player
    players_df['WC_Appearances_Cumulative'] = players_df.groupby('Player Name').cumcount()
    # Subtract 1 to ensure the current match is not counted
    players_df['Experience_Before_Match'] = players_df['WC_Appearances_Cumulative'] 
    
    print("Player experience calculated.")

    # --- 4. Aggregate to Match Level ---
    
    # Select only the starting players ('S' in Line-up) for feature calculation
    starters_df = players_df[players_df['Line-up'] == 'S'].copy()
    
    # Group by MatchID and Team Initials to get match-level stats
    agg_features = starters_df.groupby(['MatchID', 'Team Initials']).agg(
        Team_Avg_Age=('Age_Years', 'mean'),
        Team_Total_Exp=('Experience_Before_Match', 'sum')
    ).reset_index()

    # --- 5. Merge back into Matches DataFrame ---
    
    # Merge Home Team features
    matches_df = pd.merge(
        matches_df,
        agg_features.rename(columns={'Team_Avg_Age': 'home_avg_age', 'Team_Total_Exp': 'home_total_exp'}),
        left_on=['MatchID', 'Home Team Initials'],
        right_on=['MatchID', 'Team Initials'],
        how='left'
    ).drop(columns=['Team Initials'], errors='ignore')

    # Merge Away Team features
    matches_df = pd.merge(
        matches_df,
        agg_features.rename(columns={'Team_Avg_Age': 'away_avg_age', 'Team_Total_Exp': 'away_total_exp'}),
        left_on=['MatchID', 'Away Team Initials'],
        right_on=['MatchID', 'Team Initials'],
        how='left'
    ).drop(columns=['Team Initials'], errors='ignore')
    
    print("Player features merged to match data.")
    return matches_df

# --- Main Feature Engineering Script ---

# 1. Load Data (Existing Logic)
def load_data():
    if not os.path.exists(RESULTS_CLEANED_FILE) or not os.path.exists(RANKINGS_FILE):
        print("Error: Base match or ranking files not found.")
        exit()
        
    results_df = pd.read_csv(RESULTS_CLEANED_FILE)
    rankings_df = pd.read_csv(RANKINGS_FILE, encoding='utf-8')
    return results_df, rankings_df

# 2. Prepare Match Results DataFrame (Existing Logic)
def prepare_match_data(results_df):
    results_df['date'] = pd.to_datetime(results_df['date'])
    results_df.sort_values(by='date', inplace=True)
    results_df.reset_index(drop=True, inplace=True)
    results_df['home_team'] = results_df['home_team'].astype(str).str.strip()
    results_df['away_team'] = results_df['away_team'].astype(str).str.strip()
    
    results_df['home_score'] = pd.to_numeric(results_df['home_score'], errors='coerce')
    results_df['away_score'] = pd.to_numeric(results_df['away_score'], errors='coerce')
    results_df.dropna(subset=['home_score', 'away_score', 'home_team', 'away_team'], inplace=True)
    results_df['home_score'] = results_df['home_score'].astype(int)
    results_df['away_score'] = results_df['away_score'].astype(int)

    results_df['home_points'] = np.select(
        [results_df['home_score'] > results_df['away_score'], results_df['home_score'] == results_df['away_score']],
        [3, 1], default=0
    )
    results_df['away_points'] = np.select(
        [results_df['away_score'] > results_df['home_score'], results_df['home_score'] == results_df['away_score']],
        [3, 1], default=0
    )
    results_df['goal_diff_match'] = results_df['home_score'] - results_df['away_score']
    
    # Ensure MatchID is included for player feature merge
    if 'MatchID' not in results_df.columns:
         print("Warning: 'MatchID' column not found in results_cleaned.csv. Player features will fail to merge.")

    return results_df

# 3. Calculate Rolling Stats (Existing Logic)
def calculate_rolling_stats(results_df, window_size):
    print(f"\nCalculating rolling stats (Window Size = {window_size})...")
    team_history = {}
    
    # Initialize lists for features
    home_avg_pts_list = [0.0] * len(results_df)
    home_avg_gd_list = [0.0] * len(results_df)
    away_avg_pts_list = [0.0] * len(results_df)
    away_avg_gd_list = [0.0] * len(results_df)

    # Use index to track the history relative to the current match
    for index in tqdm(results_df.index, total=results_df.shape[0], desc="Calculating Rolling Stats"):
        row = results_df.iloc[index]
        home_team, away_team = row['home_team'], row['away_team']

        # Function to get rolling stats
        def get_rolling_stats(team, current_index):
            stats = team_history.get(team, [])
            # Filter games that occurred BEFORE the current game
            past_games = [game for game in stats if game[0] < current_index]
            last_n_games = past_games[-window_size:]
            
            if len(last_n_games) > 0:
                avg_pts = sum(game[1] for game in last_n_games) / len(last_n_games)
                avg_gd = sum(game[2] for game in last_n_games) / len(last_n_games)
                return avg_pts, avg_gd
            return 0.0, 0.0

        home_avg_pts_list[index], home_avg_gd_list[index] = get_rolling_stats(home_team, index)
        away_avg_pts_list[index], away_avg_gd_list[index] = get_rolling_stats(away_team, index)

        # Update Team History AFTER using the historical stats
        home_gd_match = row['goal_diff_match']
        away_gd_match = -row['goal_diff_match']
        if home_team not in team_history: team_history[home_team] = []
        if away_team not in team_history: team_history[away_team] = []
        # Store (index, points, goal_diff)
        team_history[home_team].append((index, row['home_points'], home_gd_match))
        team_history[away_team].append((index, row['away_points'], away_gd_match))

    # Add calculated rolling features to the DataFrame
    results_df[f'home_avg_pts_L{window_size}'] = home_avg_pts_list
    results_df[f'home_avg_gd_L{window_size}'] = home_avg_gd_list
    results_df[f'away_avg_pts_L{window_size}'] = away_avg_pts_list
    results_df[f'away_avg_gd_L{window_size}'] = away_avg_gd_list
    print("Rolling stats calculation complete.")
    return results_df

# 4. Merge Rankings (Existing Logic)
def merge_rankings(results_df, rankings_df):
    print("\nMerging FIFA Rankings...")
    # Clean and prepare ranking data (similar to previous step)
    rankings_df.rename(columns={'Rank': 'Rank_FIFA', 'Points': 'Points_FIFA', 'Team': 'Team_Raw'}, inplace=True)
    rankings_df['Rank_FIFA'] = pd.to_numeric(rankings_df['Rank_FIFA'], errors='coerce').fillna(1000)
    rankings_df['Points_FIFA'] = pd.to_numeric(rankings_df['Points_FIFA'], errors='coerce')
    rankings_df.dropna(subset=['Rank_FIFA', 'Points_FIFA'], inplace=True)
    
    def clean_team_name(name):
        name = str(name).strip()
        name = name.replace(" men's national soccer team", "").replace(" national football team", "").replace(" national team", "")
        if name == "United States": name = "USA"
        return name.strip()

    rankings_df['Team'] = rankings_df['Team_Raw'].apply(clean_team_name)
    rankings_to_merge = rankings_df[['Team', 'Rank_FIFA']].copy()
    rankings_to_merge['Rank_FIFA'] = rankings_to_merge['Rank_FIFA'].astype(int)
    rankings_to_merge = rankings_to_merge.sort_values(by='Rank_FIFA').drop_duplicates(subset=['Team'], keep='first')
    
    # Alignment: Assuming results.csv uses team names that match the cleaned names
    
    # Merge for Home Team
    results_df = pd.merge(
        results_df, rankings_to_merge[['Team', 'Rank_FIFA']], 
        left_on='home_team', right_on='Team', how='left'
    )
    results_df.rename(columns={'Rank_FIFA': 'home_rank'}, inplace=True)
    results_df.drop(columns=['Team'], inplace=True, errors='ignore')

    # Merge for Away Team
    results_df = pd.merge(
        results_df, rankings_to_merge[['Team', 'Rank_FIFA']],
        left_on='away_team', right_on='Team', how='left'
    )
    results_df.rename(columns={'Rank_FIFA': 'away_rank'}, inplace=True)
    results_df.drop(columns=['Team'], inplace=True, errors='ignore')
    
    # Handle NaNs and calculate diff
    median_rank = results_df['home_rank'].median()
    results_df['home_rank'] = results_df['home_rank'].fillna(median_rank)
    results_df['away_rank'] = results_df['away_rank'].fillna(median_rank)
    results_df['rank_diff'] = results_df['home_rank'] - results_df['away_rank']
    print("Ranking merge complete.")
    return results_df

# --- Execution ---
if __name__ == '__main__':
    print("Starting Feature Engineering Pipeline...")
    
    results_df, rankings_df = load_data()
    results_df = prepare_match_data(results_df)
    
    # 1. Add Rolling Stats
    results_df = calculate_rolling_stats(results_df, ROLLING_WINDOW_SIZE)
    
    # 2. Add Rankings Features
    results_df = merge_rankings(results_df, rankings_df)
    
    # 3. Add Player Features (NEW REQUIRED STEP)
    # NOTE: This step assumes the user has created the BIRTH_DATES_FILE!
    results_df = load_and_calculate_player_features(results_df) 

    # --- Final Data Cleanup and Save ---
    
    # Keep only relevant columns for the ML model (and save MatchID for future reference)
    final_cols = [
        col for col in results_df.columns if col.startswith(('home_', 'away_', 'rank_diff', 'MatchID', 'date', 'neutral', 'Year', 'Stage'))
    ]
    final_df = results_df[final_cols].copy()
    
    print("\nPreview of Final DataFrame:")
    print(final_df.iloc[-5:].T)

    print(f"\nSaving final data with all features to '{OUTPUT_FILE}'...")
    final_df.to_csv(OUTPUT_FILE, index=False)
    print(f"Saved successfully. Columns added: home_avg_age, away_avg_age, home_total_exp, away_total_exp.")